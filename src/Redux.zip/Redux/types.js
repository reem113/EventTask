export const SET_POSTS = 'SET_POSTS';
export const SET_POSTS_SUCCESS = 'SET_POSTS_SUCCESS';